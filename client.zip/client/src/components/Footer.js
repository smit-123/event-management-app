import React from 'react'

const Footer = () => {
    return (
        // <footer class="bg-dark text-light text-center py-2 bottom-0">
        //     &copy; 2023 FindMyEvents. All rights reserved.
        // </footer>
        <></>

    )
}

export default Footer